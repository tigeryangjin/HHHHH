-----�����ƹ� 
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct IP) �ջ�,
               count(distinct c.vid) ע��,
               count(distinct b.vid) ����,
               VISIT_DATE_KEY
          from (select VID, IP, VISIT_DATE_KEY
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and (url like '%fo=HBTG%')
                 group by VID, IP, VISIT_DATE_KEY) a
          left join
        
         (select VID, FIST_IP, START_DATE_KEY
           from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                   from fact_session
                  where START_DATE_KEY between
                        to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')
                    and APPLICATION_KEY > 20) s
           join (select MEMBER_CRMBP, MEMBER_TIME
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')) ss
             on s.MEMBER_KEY = ss.MEMBER_CRMBP
            and s.START_DATE_KEY = ss.MEMBER_TIME
          group by VID, FIST_IP, START_DATE_KEY) c
            on
        
         (a.ip = c.FIST_IP and a.VISIT_DATE_KEY = c.START_DATE_KEY)
          left join
        
         (select VID, ORDER_IP, add_time
           from factec_order
          where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                to_char(sysdate - 1, 'yyyymmdd')
            and order_state > 10
          group by VID, ORDER_IP, add_time) b
            on (a.ip = b.ORDER_IP and a.VISIT_DATE_KEY = b.add_time)
         group by VISIT_DATE_KEY);
-----˫������ 
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct IP) �ջ�,
               count(distinct c.vid) ע��,
               count(distinct b.vid) ����,
               VISIT_DATE_KEY
          from (select VID, IP, VISIT_DATE_KEY
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and (url like '%fo=SPHD%')
                 group by VID, IP, VISIT_DATE_KEY) a
          left join
        
         (select VID, FIST_IP, START_DATE_KEY
           from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                   from fact_session
                  where START_DATE_KEY between
                        to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')
                    and APPLICATION_KEY > 20) s
           join (select MEMBER_CRMBP, MEMBER_TIME
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')) ss
             on s.MEMBER_KEY = ss.MEMBER_CRMBP
            and s.START_DATE_KEY = ss.MEMBER_TIME
          group by VID, FIST_IP, START_DATE_KEY) c
            on
        
         (a.ip = c.FIST_IP and a.VISIT_DATE_KEY = c.START_DATE_KEY)
          left join
        
         (select VID, ORDER_IP, add_time
           from factec_order
          where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                to_char(sysdate - 1, 'yyyymmdd')
            and order_state > 10
          group by VID, ORDER_IP, add_time) b
            on (a.ip = b.ORDER_IP and a.VISIT_DATE_KEY = b.add_time)
         group by VISIT_DATE_KEY);

----����  ����
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct IP) �ջ�,
               count(distinct c.vid) ע��,
               count(distinct b.vid) ����,
               VISIT_DATE_KEY
          from (select VID, IP, VISIT_DATE_KEY
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and (url like '%DXTX%')
                 group by VID, IP, VISIT_DATE_KEY) a
          left join
        
         (select VID, FIST_IP, START_DATE_KEY
           from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                   from fact_session
                  where START_DATE_KEY between
                        to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')
                    and APPLICATION_KEY > 20) s
           join (select MEMBER_CRMBP, MEMBER_TIME
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')) ss
             on s.MEMBER_KEY = ss.MEMBER_CRMBP
            and s.START_DATE_KEY = ss.MEMBER_TIME
          group by VID, FIST_IP, START_DATE_KEY) c
            on
        
         (a.ip = c.FIST_IP and a.VISIT_DATE_KEY = c.START_DATE_KEY)
          left join
        
         (select VID, ORDER_IP, add_time
           from factec_order
          where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                to_char(sysdate - 1, 'yyyymmdd')
            and order_state > 10
          group by VID, ORDER_IP, add_time) b
            on (a.ip = b.ORDER_IP and a.VISIT_DATE_KEY = b.add_time)
         group by VISIT_DATE_KEY);

-------����  ԤԼ���� 
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct IP) �ջ�,
               count(distinct c.vid) ע��,
               count(distinct b.vid) ����,
               VISIT_DATE_KEY
          from (select VID, IP, VISIT_DATE_KEY
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and (url like '%fo=YYTX%')
                 group by VID, IP, VISIT_DATE_KEY) a
          left join
        
         (select VID, FIST_IP, START_DATE_KEY
           from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                   from fact_session
                  where START_DATE_KEY between
                        to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')
                    and APPLICATION_KEY > 20) s
           join (select MEMBER_CRMBP, MEMBER_TIME
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')) ss
             on s.MEMBER_KEY = ss.MEMBER_CRMBP
            and s.START_DATE_KEY = ss.MEMBER_TIME
          group by VID, FIST_IP, START_DATE_KEY) c
            on
        
         (a.VID = c.VID and a.VISIT_DATE_KEY = c.START_DATE_KEY)
          left join
        
         (select VID, ORDER_IP, add_time
           from factec_order
          where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                to_char(sysdate - 1, 'yyyymmdd')
            and order_state > 10
          group by VID, ORDER_IP, add_time) b
            on (a.VID = b.VID and a.VISIT_DATE_KEY = b.add_time)
         group by VISIT_DATE_KEY);

------����  ΢������ 
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct IP) �ջ�,
               count(distinct c.vid) ע��,
               count(distinct b.vid) ����,
               VISIT_DATE_KEY
          from (select VID, IP, VISIT_DATE_KEY
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and (url like '%wkzt%' or url like '%wksp%')
                 group by VID, IP, VISIT_DATE_KEY) a
          left join
        
         (select VID, FIST_IP, START_DATE_KEY
           from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                   from fact_session
                  where START_DATE_KEY between
                        to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')
                    and APPLICATION_KEY > 20) s
           join (select MEMBER_CRMBP, MEMBER_TIME
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')) ss
             on s.MEMBER_KEY = ss.MEMBER_CRMBP
            and s.START_DATE_KEY = ss.MEMBER_TIME
          group by VID, FIST_IP, START_DATE_KEY) c
            on
        
         (a.ip = c.FIST_IP and a.VISIT_DATE_KEY = c.START_DATE_KEY)
          left join
        
         (select VID, ORDER_IP, add_time
           from factec_order
          where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                to_char(sysdate - 1, 'yyyymmdd')
            and order_state > 10
          group by VID, ORDER_IP, add_time) b
            on (a.ip = b.ORDER_IP and a.VISIT_DATE_KEY = b.add_time)
         group by VISIT_DATE_KEY);

------DM��
select avg(�ջ�), avg(ע��), avg(����)
  from (select count(distinct a.vid) �ջ�,
                count(distinct c.vid) ע��,
                count(distinct b.vid) ����,
                VISIT_DATE_KEY
           from (select VID, START_DATE_KEY as VISIT_DATE_KEY
                   from (select *
                           from (select VID,
                                        substr(VID, 3, 200) vid1,
                                        START_DATE_KEY
                                   from fact_session
                                  where START_DATE_KEY between
                                        to_char(sysdate - 7, 'yyyymmdd') and
                                        to_char(sysdate - 1, 'yyyymmdd')
                                    and APPLICATION_KEY = 50
                                  group by substr(VID, 3, 200),
                                           START_DATE_KEY,
                                           VID) a
                           left join (select OPENID, CREATE_TIME
                                       from fact_wx_excode
                                      where CREATE_TIME between
                                            to_char(sysdate - 7, 'yyyymmdd') and
                                            to_char(sysdate - 1, 'yyyymmdd')) b
                             on a.vid1 = b.OPENID
                            and a.START_DATE_KEY = b.CREATE_TIME)
                  where OPENID is not null) a
           left join
         
          (select VID, FIST_IP, START_DATE_KEY
            from (select VID, FIST_IP, START_DATE_KEY, MEMBER_KEY
                    from fact_session
                   where START_DATE_KEY between
                         to_char(sysdate - 7, 'yyyymmdd') and
                         to_char(sysdate - 1, 'yyyymmdd')
                     and APPLICATION_KEY > 20) s
            join (select MEMBER_CRMBP, MEMBER_TIME
                   from fact_ecmember
                  where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                        to_char(sysdate - 1, 'yyyymmdd')) ss
              on s.MEMBER_KEY = ss.MEMBER_CRMBP
             and s.START_DATE_KEY = ss.MEMBER_TIME
           group by VID, FIST_IP, START_DATE_KEY) c
             on
         
          a.VID = c.VID
       and a.VISIT_DATE_KEY = c.START_DATE_KEY
           left join
         
          (select VID, ORDER_IP, add_time
            from factec_order
           where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                 to_char(sysdate - 1, 'yyyymmdd')
             and order_state > 10
           group by VID, ORDER_IP, add_time) b
             on (a.VID = b.VID and a.VISIT_DATE_KEY = b.add_time)
          group by VISIT_DATE_KEY);

--------ɨ�빺

select (SELECT AVG(num1)
          from (select COUNT(DISTINCT VID) num1, visit_date_key
                  from fact_page_view
                 where visit_date_key between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and page_name = 'TV_QRC'
                 group by visit_date_key)) as �ջ�,
       
       (select count(distinct MEMBER_KEY) / 7
          from fact_session
         where START_DATE_KEY between to_char(sysdate - 7, 'yyyymmdd') and
               to_char(sysdate - 1, 'yyyymmdd')
           and vid in
               (select VID
                  from dim_vid_scan
                 where SCAN_DATE_KEY between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd'))
           and MEMBER_KEY in
               (select MEMBER_CRMBP
                  from fact_ecmember
                 where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd'))) as ע������,
       
       (SELECT AVG(num2)
          from (select count(distinct MEMBER_KEY) num2, add_time
                  from factec_order
                 where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and order_state > 10
                   and order_from = 76
                 group by add_time)) as ��������
  from dual;

---��������
select (select avg(num1)
          from (select count(distinct vid) num1, START_DATE_KEY
                  from fact_session
                 where START_DATE_KEY between
                       to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                 group by START_DATE_KEY)) as �ջ�,
       (select count(1) / 7
          from fact_ecmember
         where MEMBER_TIME between to_char(sysdate - 7, 'yyyymmdd') and
               to_char(sysdate - 1, 'yyyymmdd')) as ע������,
       (SELECT AVG(num2)
          from (select count(distinct MEMBER_KEY) num2, add_time
                  from factec_order
                 where add_time between to_char(sysdate - 7, 'yyyymmdd') and
                       to_char(sysdate - 1, 'yyyymmdd')
                   and order_state > 10
                 group by add_time)) as ��������
  from dual;
