----- 0��ת1���û�

insert into  ls_test(ssid)
select MEMBER_KEY from (
select MEMBER_KEY,count(1) num1 from fact_order where  POSTING_DATE_KEY < 20171201 and order_state=1
group by  MEMBER_KEY);
select count(distinct MEMBER_KEY ) from fact_session where  START_DATE_KEY between  20171201 and  20171207
and MEMBER_KEY not in (
select ssid from  ls_test
);
truncate table ls_test;
----- 1��ת2���û�
insert into  ls_test(ssid)
select MEMBER_KEY from (
select MEMBER_KEY,count(1) num1 from fact_order where  POSTING_DATE_KEY < 20171201 and order_state=1
group by  MEMBER_KEY) where num1=1;
select count(distinct MEMBER_KEY ) from fact_session where  START_DATE_KEY between  20171201 and  20171207
and MEMBER_KEY in (
select ssid from  ls_test
);
truncate table ls_test;
----- 2��ת3���û�
insert into  ls_test(ssid)
select MEMBER_KEY from (
select MEMBER_KEY,count(1) num1 from fact_order where  POSTING_DATE_KEY < 20171201 and order_state=1
group by  MEMBER_KEY) where num1=2;
select count(distinct MEMBER_KEY ) from fact_session where  START_DATE_KEY between  20171201 and  20171207
and MEMBER_KEY in (
select ssid from  ls_test
);
truncate table ls_test;
----- 3��ת4���û�
insert into  ls_test(ssid)
select MEMBER_KEY from (
select MEMBER_KEY,count(1) num1 from fact_order where  POSTING_DATE_KEY < 20171201 and order_state=1
group by  MEMBER_KEY) where num1=3;
select count(distinct MEMBER_KEY ) from fact_session where  START_DATE_KEY between  20171201 and  20171207
and MEMBER_KEY in (
select ssid from  ls_test
);
truncate table ls_test;
----- 4��ת5���û�
insert into  ls_test(ssid)
select MEMBER_KEY from (
select MEMBER_KEY,count(1) num1 from fact_order where  POSTING_DATE_KEY < 20171201 and order_state=1
group by  MEMBER_KEY) where num1=4;
select count(distinct MEMBER_KEY ) from fact_session where  START_DATE_KEY between  20171201 and  20171207
and MEMBER_KEY in (
select ssid from  ls_test
);
truncate table ls_test;



